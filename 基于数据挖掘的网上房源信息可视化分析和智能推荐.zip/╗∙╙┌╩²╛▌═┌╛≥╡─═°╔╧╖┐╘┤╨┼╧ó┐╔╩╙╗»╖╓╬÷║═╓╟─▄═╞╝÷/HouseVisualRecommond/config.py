# coding=utf-8
DEBUG = True # 启动Flask的Debug模式
