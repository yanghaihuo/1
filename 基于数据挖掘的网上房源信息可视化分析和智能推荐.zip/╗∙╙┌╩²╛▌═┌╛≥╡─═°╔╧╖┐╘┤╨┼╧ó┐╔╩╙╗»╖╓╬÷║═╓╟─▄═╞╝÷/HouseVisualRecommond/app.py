#!/usr/bin/python
# coding=utf-8

import sqlite3

from flask import Flask, render_template, jsonify
import numpy as np

# 神经网络模型工具包

app = Flask(__name__)
app.config.from_object('config')

login_name = None


# --------------------- html render ---------------------
@app.route('/')
def index():
    return render_template('index.html')


@app.route('/house_info')
def house_info():
    return render_template('house_info.html')


@app.route('/influence_analysis')
def influence_analysis():
    return render_template('influence_analysis.html')


@app.route('/recommend_house')
def recommend_house():
    return render_template('recommend_house.html')


@app.route('/house_map')
def house_map():
    return render_template('house_map.html')


@app.route('/recommend')
def recommend():
    return render_template('recommend.html')


# ------------------ ajax restful api -------------------
@app.route('/check_login')
def check_login():
    """判断用户是否登录"""
    return jsonify({'username': login_name, 'login': login_name is not None})


@app.route('/register/<name>/<password>')
def register(name, password):
    conn = sqlite3.connect('user_info.db')
    cursor = conn.cursor()

    check_sql = "SELECT * FROM sqlite_master where type='table' and name='user'"
    cursor.execute(check_sql)
    results = cursor.fetchall()
    # 数据库表不存在
    if len(results) == 0:
        # 创建数据库表
        sql = """
                CREATE TABLE user(
                    name CHAR(256), 
                    password CHAR(256)
                );
                """
        cursor.execute(sql)
        conn.commit()
        print('创建数据库表成功！')

    sql = "INSERT INTO user (name, password) VALUES (?,?);"
    cursor.executemany(sql, [(name, password)])
    conn.commit()
    return jsonify({'info': '用户注册成功！', 'status': 'ok'})


@app.route('/login/<name>/<password>')
def login(name, password):
    global login_name
    conn = sqlite3.connect('user_info.db')
    cursor = conn.cursor()

    check_sql = "SELECT * FROM sqlite_master where type='table' and name='user'"
    cursor.execute(check_sql)
    results = cursor.fetchall()
    # 数据库表不存在
    if len(results) == 0:
        # 创建数据库表
        sql = """
                CREATE TABLE user(
                    name CHAR(256), 
                    password CHAR(256)
                );
                """
        cursor.execute(sql)
        conn.commit()
        print('创建数据库表成功！')

    sql = "select * from user where name='{}' and password='{}'".format(name, password)
    cursor.execute(sql)
    results = cursor.fetchall()

    login_name = name
    if len(results) > 0:
        print(results)
        return jsonify({'info': name + '用户登录成功！', 'status': 'ok'})
    else:
        return jsonify({'info': '当前用户不存在！', 'status': 'error'})


@app.route('/fetch_house_area_and_price')
def fetch_house_area_and_price():
    """获取房屋面积和价格数据"""
    conn = sqlite3.connect('all_house_infos.db')
    cursor = conn.cursor()

    sql = 'select 总价, 建筑面积, 房屋户型_室数, 房屋户型_厅数, 房屋户型_卫数 from HouseInfo'
    cursor.execute(sql)
    datas = cursor.fetchall()

    results = {'面积': [], '每间房间的面积': [], '总价': []}
    for data in datas:
        zongjia, mianji, huxin_s, huxin_t, huxin_w = data
        # 房间数
        fanjian_count = huxin_s + huxin_t + huxin_w
        # 每间房间的面积
        per_fanjian = mianji / fanjian_count
        results['面积'].append(mianji)
        results['每间房间的面积'].append(per_fanjian)
        results['总价'].append(zongjia)

    return jsonify(results)


@app.route('/fetch_influence_analysis_datas/<key>')
def fetch_influence_analysis_datas(key):
    """获取影响房价因素分析的数据"""
    conn = sqlite3.connect('all_house_infos.db')
    cursor = conn.cursor()

    sql = 'select {}, 总价 from HouseInfo'.format(key)
    cursor.execute(sql)
    datas = cursor.fetchall()

    results = {}
    for data in datas:
        key, value = data
        if key not in results:
            results[key] = [value]
        else:
            results[key].append(value)

    counts = []
    for key in results:
        counts.append(len(results[key]))
        results[key] = np.mean(results[key])

    results = list(zip(list(results.keys()), counts, list(results.values())))
    results = sorted(results, key=lambda k: k[2], reverse=False)
    zhibiao = [r[0] for r in results]
    counts = [r[1] for r in results]
    junjia = [r[2] for r in results]

    return jsonify({'指标': zhibiao, '个数': counts, '均价': junjia})


@app.route('/select_house_info/<xiaoqu>')
def select_house_info(xiaoqu):
    """当前小区的历史价格，以及针对当前配置预测的价格"""
    conn = sqlite3.connect('all_house_infos.db')
    cursor = conn.cursor()

    sql = "select 房屋户型_室数, 房屋户型_厅数, 房屋户型_卫数, 房屋朝向, 装修程度, 配套电梯, 建筑面积, 总价 from HouseInfo where 所属小区='{}'".format(xiaoqu)

    cursor.execute(sql)
    datas = cursor.fetchall()

    results = {'面积': [], '总价': [], '房屋户型_室数': [], '房屋户型_厅数': [], '房屋户型_卫数': [], '房屋朝向': [], '装修程度': [], '配套电梯': []}
    for data in datas:
        shi, ting, wei, chaoxiang, zhuangxiu, dianti, mianji, zongjia = data
        results['房屋户型_室数'].append(shi)
        results['房屋户型_厅数'].append(ting)
        results['房屋户型_卫数'].append(wei)
        results['房屋朝向'].append(chaoxiang)
        results['装修程度'].append(zhuangxiu)
        results['配套电梯'].append(dianti)
        results['面积'].append(mianji)
        results['总价'].append(zongjia)

    return jsonify(results)


@app.route('/get_all_unique_values/<key>')
def get_all_unique_values(key):
    """获取当前指标所有的唯一值"""
    conn = sqlite3.connect('all_house_infos.db')
    cursor = conn.cursor()

    sql = "select distinct {} from HouseInfo".format(key)
    cursor.execute(sql)
    datas = cursor.fetchall()

    key_count = {}
    for data in datas:
        sql = "select count(*) from HouseInfo where {}='{}'".format(key, data[0])
        cursor.execute(sql)
        count = cursor.fetchall()[0][0]
        key_count[data[0]] = count

    key_count = sorted(key_count.items(), key=lambda d: d[1], reverse=True)

    return jsonify(key_count)


# 初始化解决冷启动问题
chaoxiangs = ['南']
zhuangxius = ['精装修']
diantis = ['有']
mianjis = [110]
shoujias = [1800000]


@app.route('/shoucang/<chaoxiang>/<zhuangxiu>/<dianti>/<mianji>/<shoujia>')
def shoucang(chaoxiang, zhuangxiu, dianti, mianji, shoujia):
    chaoxiangs.append(chaoxiang)
    zhuangxius.append(zhuangxiu)
    diantis.append(dianti)
    mianjis.append(float(mianji))
    shoujias.append(float(shoujia))
    return jsonify({})


@app.route('/recommand')
def recommand():
    """当前小区的历史价格，以及针对当前配置预测的价格"""
    conn = sqlite3.connect('all_house_infos.db')
    cursor = conn.cursor()

    chaoxiang = max(chaoxiangs, key=chaoxiangs.count)

    zhuangxiu = max(zhuangxius, key=zhuangxius.count)
    dianti = max(diantis, key=diantis.count)
    mean_shoujia = sum(shoujias) / len(shoujias)

    sql = "select  所属小区,房屋户型_室数, 房屋户型_厅数, 房屋户型_卫数, 房屋朝向, 装修程度, 配套电梯, 建筑面积, 总价 from HouseInfo where 房屋朝向 in ('{}','{}') and 装修程度 in ('{}','{}') and 配套电梯='{}'".format(chaoxiang, max2(chaoxiangs), zhuangxiu, max2(zhuangxius), dianti)

    cursor.execute(sql)
    datas = cursor.fetchall()
    print(datas)
    results = { '所属小区': [],'面积': [], '总价': [], '房屋户型_室数': [], '房屋户型_厅数': [], '房屋户型_卫数': [], '房屋朝向': [], '装修程度': [], '配套电梯': []}
    for data in datas:
        xiaoqu,shi, ting, wei, chaoxiang, zhuangxiu, dianti, mianji, zongjia = data
        if mean_shoujia * 0.95 < zongjia < mean_shoujia * 1.05:
            results['所属小区'].append(xiaoqu)
            results['房屋户型_室数'].append(shi)
            results['房屋户型_厅数'].append(ting)
            results['房屋户型_卫数'].append(wei)
            results['房屋朝向'].append(chaoxiang)
            results['装修程度'].append(zhuangxiu)
            results['配套电梯'].append(dianti)
            results['面积'].append(mianji)
            results['总价'].append(zongjia)

    return jsonify(results)


def max2(a):
    as1 = a
    a1 = max(a, key=a.count)
    for i in range(0,a.count(a1)):
        as1.remove(a1)
    as2 = max(as1, key=as1.count)
    return as2

if __name__ == "__main__":
    app.run(host='127.0.0.1')
